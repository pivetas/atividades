/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class Estados {

    public enum qte {
        aguardando, sucesso, falhou

    }

    public enum SpriteInimigo {
        parado, atacando, recebendoDano
    }

    public enum SpritePersonagem {
        parado, defendendo, RecebendoDano, atacando
    }

    private Estados() {
    }

}
