/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import javax.swing.JLabel;
import javax.swing.Timer;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class QuickTimeEvent {

    private Estados.qte estado = Estados.qte.aguardando;

    private Timer timerLimite;
    private JLabel labelStatus;
    private personagem Personagem;
    private inimigo Inimigo;

    private sprite<Estados.SpritePersonagem> spritePersonagem;
    private sprite<Estados.SpriteInimigo> spriteInimigo;

    private Runnable aoTerminar;

    public void setAoTerminar(Runnable aoTerminar) {
        this.aoTerminar = aoTerminar;
    }

    public QuickTimeEvent(JLabel labelStatus, personagem Personagem, inimigo Inimigo, sprite<Estados.SpritePersonagem> spritePersonagem, sprite<Estados.SpriteInimigo> spriteInimigo) {
        this.labelStatus = labelStatus;
        this.Personagem = Personagem;
        this.Inimigo = Inimigo;
        this.spritePersonagem = spritePersonagem;
        this.spriteInimigo = spriteInimigo;

    }

    public void iniciar() {
        estado = Estados.qte.aguardando;
        labelStatus.setText("aperte espaço para reagir");

        spriteInimigo.setEstado(Estados.SpriteInimigo.atacando);
        spritePersonagem.setEstado(Estados.SpritePersonagem.parado);

        timerLimite = new Timer(800, e -> {
            if (estado == Estados.qte.aguardando) {
                estado = Estados.qte.falhou;

                timerLimite.stop();
                finalizar();

            }
        });
        timerLimite.setRepeats(false);
        timerLimite.start();

    }

    public void reagir() {
        if (estado == Estados.qte.aguardando) {
            estado = Estados.qte.sucesso;
            timerLimite.stop();
            finalizar();
        }
    }

    private void finalizar() {
        switch (estado) {
            case sucesso -> {
                labelStatus.setText("defendeu o ataque");
                spritePersonagem.setEstado(Estados.SpritePersonagem.defendendo);
                spriteInimigo.setEstado(Estados.SpriteInimigo.parado);

                Timer timerContraAtaque = new Timer(300, e -> {
                    spritePersonagem.setEstado(Estados.SpritePersonagem.atacando);
                    spriteInimigo.setEstado(Estados.SpriteInimigo.recebendoDano);
                    Inimigo.receberDano(10);
                });
                timerContraAtaque.setRepeats(false);
                timerContraAtaque.start();
            }
            case falhou -> {
                labelStatus.setText("voce nao reagiu a tempo");
                spritePersonagem.setEstado(Estados.SpritePersonagem.RecebendoDano);
                spriteInimigo.setEstado(Estados.SpriteInimigo.parado);
                Personagem.receberDano(15);
            }
            case aguardando -> {

            }
        }
        Timer timerReset = new Timer(700, e -> resetarSprites());
        timerReset.setRepeats(false);
        timerReset.start();

    }

    public void resetarSprites() {
        spritePersonagem.setEstado(Estados.SpritePersonagem.parado);
        spriteInimigo.setEstado(Estados.SpriteInimigo.parado);
        if (aoTerminar != null) {
            aoTerminar.run();
        }

    }

    public Estados.qte getEstado() {
        return estado;
    }

}
