/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public abstract class entidades {
    
    protected int vida;
    
    public entidades (int VidaInicial){
        this.vida=VidaInicial;
    }
    public int getVida(){
        return vida;
    }
    public boolean estaVivo  (){
        return vida>0;
    }
    public void receberDano (int dano){
        this.vida=Math.max(0, this.vida-dano);
    }
}
