/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class inimigo extends entidades{
    
    public inimigo() {
        super(200);
    }
    
}
