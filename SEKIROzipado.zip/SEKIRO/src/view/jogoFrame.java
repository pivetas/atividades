/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.EnumMap;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class jogoFrame extends JFrame {

    public jogoFrame() {
        setLayout(new FlowLayout());

        JLabel labelStatus = new JLabel("aguardando ataque inimigo");
JLabel labelSpritePersonagem= new JLabel();
JLabel labelSpriteInimigo = new JLabel();

add(labelSpritePersonagem);
add(labelSpriteInimigo);
add(labelStatus);

personagem Personagem= new personagem();
inimigo Inimigo = new inimigo();

Map<Estados.SpriteInimigo, String> caminhosInimigo = new EnumMap<>(Estados.SpriteInimigo.class);
caminhosInimigo.put(Estados.SpriteInimigo.parado, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\ishhin normal.png");
caminhosInimigo.put(Estados.SpriteInimigo.atacando, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\ishin ataque.png");
caminhosInimigo.put(Estados.SpriteInimigo.recebendoDano, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\ishhin dano.png");

sprite<Estados.SpriteInimigo> spriteInimigo = new sprite<>(
        labelSpriteInimigo,
        Estados.SpriteInimigo.class,
        caminhosInimigo,
        Estados.SpriteInimigo.parado
);

Map<Estados.SpritePersonagem, String> caminhosPersonagem = new EnumMap<>(Estados.SpritePersonagem.class);
caminhosPersonagem.put(Estados.SpritePersonagem.parado, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\image.olhando pra frente base-Photoroom.png");
caminhosPersonagem.put(Estados.SpritePersonagem.defendendo, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\sekiro defendendo ataque.png");
caminhosPersonagem.put(Estados.SpritePersonagem.atacando, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\defesa sekiro.png");
caminhosPersonagem.put(Estados.SpritePersonagem.RecebendoDano, "C:\\Users\\PABLOSOMAVILLADEMELL\\Pictures\\sekiro game\\animaçao lobo\\sekiro dano.png");

sprite<Estados.SpritePersonagem> spritePersonagem = new sprite<>(
        labelSpritePersonagem,
        Estados.SpritePersonagem.class,
        caminhosPersonagem,
        Estados.SpritePersonagem.parado
);


     QuickTimeEvent qte= new QuickTimeEvent(labelStatus, Personagem, Inimigo, spritePersonagem, spriteInimigo);
        Random random = new Random();
 
    qte.setAoTerminar(()->{ if(Personagem.estaVivo() && Inimigo.estaVivo()){
        int Atraso= 1000 + random.nextInt(2001);
        
        Timer timerProximoAtaque = new Timer(Atraso,e ->qte.iniciar());
timerProximoAtaque.setRepeats(false);
timerProximoAtaque.start();
     }else if (!Personagem.estaVivo()){
         labelStatus.setText("voce foi derrotado");
     }else {
         labelStatus.setText("voce venceu");
     
     }
    }); 
    
     
     
     Timer timerAtaque= new Timer(2000,e -> qte.iniciar());
     timerAtaque.setRepeats(false);
     timerAtaque.start();
     
JRootPane rootPane= getRootPane();
rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "reagir");

rootPane.getActionMap().put("reagir",new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
qte.reagir();            }
        });

       setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);




    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(jogoFrame::new);
    }
}
