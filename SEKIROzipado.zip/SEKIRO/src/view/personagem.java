/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class personagem extends entidades{
    
    public personagem() {
        super(100);
        
    }
    public void receberDano(int dano){
        super.receberDano(dano);
        System.out.println("personagem recebeu "+dano+" de dano, sua vida atual é "+ vida);
    }
}
