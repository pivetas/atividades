/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.util.EnumMap;
import java.util.Map;
/**
 *
 * @author PABLOSOMAVILLADEMELL
 */
public class sprite<T extends  Enum<T>>{
    private Map<T, ImageIcon> imagens;
    private JLabel labelSprite;
    private T estadoAtual;
    
    public sprite(JLabel labelSprite, Class<T> tipoEnum, Map<T, String> caminhosImagens, T estadoInicial){
        this.labelSprite=labelSprite;
        this.imagens=new EnumMap<>(tipoEnum);
        
        
     for(Map.Entry<T, String> entry : caminhosImagens.entrySet()){
        ImageIcon icone = new ImageIcon(entry.getValue());
        if (icone.getIconWidth() == -1) {
            System.out.println("[ERRO] Não consegui carregar a imagem para o estado '"
                    + entry.getKey() + "'. Caminho usado: " + entry.getValue());
        }
        imagens.put(entry.getKey(), icone);
    }
   
    
    
    
    this.estadoAtual=estadoInicial;
   atualizarImagem();
    } 
    public void setEstado( T novoEstado){
        this.estadoAtual=novoEstado;
        atualizarImagem();
    }
    private void atualizarImagem(){
        labelSprite.setIcon(imagens.get(estadoAtual));
    }
    
}
